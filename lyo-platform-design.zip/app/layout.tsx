import type React from "react"
import type { Metadata } from "next"
import { Inter, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono" })

export const metadata: Metadata = {
  title: "LYO - Your AI-Powered Communication Hub",
  description:
    "Centralize all your communications with an intelligent AI agent. WhatsApp, Gmail, LinkedIn, Instagram, and Calendar in one place.",
  keywords: ["AI", "communication", "automation", "WhatsApp", "Gmail", "LinkedIn", "calendar", "productivity"],
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} ${geistMono.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
