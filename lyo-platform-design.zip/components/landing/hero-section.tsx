"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { ChevronRight, Mail, Sparkles, Zap, Brain } from "lucide-react"
import Link from "next/link"

const GmailIcon = () => (
  <svg viewBox="0 0 24 24" className="h-5 w-5">
    <path
      fill="#EA4335"
      d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.273H1.636A1.636 1.636 0 0 1 0 19.366V5.457c0-2.023 2.309-3.178 3.927-1.964L5.455 4.64 12 9.548l6.545-4.91 1.528-1.145C21.69 2.28 24 3.434 24 5.457z"
    />
  </svg>
)

const SlackIcon = () => (
  <svg viewBox="0 0 24 24" className="h-5 w-5">
    <path
      fill="#E01E5A"
      d="M5.042 15.165a2.528 2.528 0 0 1-2.52 2.523A2.528 2.528 0 0 1 0 15.165a2.527 2.527 0 0 1 2.522-2.52h2.52v2.52zm1.271 0a2.527 2.527 0 0 1 2.521-2.52 2.527 2.527 0 0 1 2.521 2.52v6.313A2.528 2.528 0 0 1 8.834 24a2.528 2.528 0 0 1-2.521-2.522v-6.313z"
    />
    <path
      fill="#36C5F0"
      d="M8.834 5.042a2.528 2.528 0 0 1-2.521-2.52A2.528 2.528 0 0 1 8.834 0a2.528 2.528 0 0 1 2.521 2.522v2.52H8.834zm0 1.271a2.528 2.528 0 0 1 2.521 2.521 2.528 2.528 0 0 1-2.521 2.521H2.522A2.528 2.528 0 0 1 0 8.834a2.528 2.528 0 0 1 2.522-2.521h6.312z"
    />
    <path
      fill="#2EB67D"
      d="M18.956 8.834a2.528 2.528 0 0 1 2.522-2.521A2.528 2.528 0 0 1 24 8.834a2.528 2.528 0 0 1-2.522 2.521h-2.522V8.834zm-1.27 0a2.528 2.528 0 0 1-2.522 2.521 2.528 2.528 0 0 1-2.521-2.521V2.522A2.528 2.528 0 0 1 15.165 0a2.528 2.528 0 0 1 2.521 2.522v6.312z"
    />
    <path
      fill="#ECB22E"
      d="M15.165 18.956a2.528 2.528 0 0 1 2.521 2.522A2.528 2.528 0 0 1 15.165 24a2.527 2.527 0 0 1-2.521-2.522v-2.522h2.521zm0-1.27a2.527 2.527 0 0 1-2.521-2.522 2.527 2.527 0 0 1 2.521-2.521h6.313A2.528 2.528 0 0 1 24 15.165a2.528 2.528 0 0 1-2.522 2.521h-6.313z"
    />
  </svg>
)

const InstagramIcon = () => (
  <svg viewBox="0 0 24 24" className="h-5 w-5">
    <defs>
      <linearGradient id="ig-grad" x1="0%" y1="100%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#FFDC80" />
        <stop offset="25%" stopColor="#F77737" />
        <stop offset="50%" stopColor="#E1306C" />
        <stop offset="75%" stopColor="#C13584" />
        <stop offset="100%" stopColor="#833AB4" />
      </linearGradient>
    </defs>
    <path
      fill="url(#ig-grad)"
      d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"
    />
  </svg>
)

const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" className="h-5 w-5">
    <path
      fill="#25D366"
      d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"
    />
  </svg>
)

const LinkedInIcon = () => (
  <svg viewBox="0 0 24 24" className="h-5 w-5">
    <path
      fill="#0A66C2"
      d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"
    />
  </svg>
)

const CalendarIcon = () => (
  <svg viewBox="0 0 24 24" className="h-5 w-5">
    <path
      fill="#4285F4"
      d="M19.5 3h-3V1.5h-1.5V3h-6V1.5H7.5V3h-3C3.675 3 3 3.675 3 4.5v15c0 .825.675 1.5 1.5 1.5h15c.825 0 1.5-.675 1.5-1.5v-15c0-.825-.675-1.5-1.5-1.5zm0 16.5h-15V8.25h15v11.25z"
    />
    <path fill="#EA4335" d="M7.5 10.5h3v3h-3z" />
    <path fill="#FBBC05" d="M10.5 10.5h3v3h-3z" />
    <path fill="#34A853" d="M13.5 10.5h3v3h-3z" />
    <path fill="#4285F4" d="M7.5 13.5h3v3h-3z" />
    <path fill="#EA4335" d="M10.5 13.5h3v3h-3z" />
  </svg>
)

const conversations = [
  {
    name: "Natasha Corwin",
    time: "3m",
    preview: "Quiere que compartas un contrato de venta de Brightstone Realty...",
    channel: "gmail",
    avatar: "NC",
  },
  {
    name: "Luke Rankin",
    time: "5m",
    preview: "Comparte una actualización del proyecto ITWA con el progreso más reciente...",
    channel: "linkedin",
    avatar: "LR",
  },
  {
    name: "Jack Callaghan",
    time: "8m",
    preview: "Comparte el plan de reunión del próximo mes con fechas y agenda...",
    channel: "slack",
    avatar: "JC",
  },
  {
    name: "Monroe",
    time: "7m",
    preview: "Información del gasto Q3, incluyendo desglose de gastos totales...",
    channel: "whatsapp",
    avatar: "MO",
  },
  {
    name: "Rivers",
    time: "4 Ago",
    preview: "Los últimos bocetos de diseño del equipo creativo...",
    channel: "instagram",
    avatar: "RV",
  },
]

const channelIcons: Record<string, React.ReactNode> = {
  gmail: <GmailIcon />,
  slack: <SlackIcon />,
  instagram: <InstagramIcon />,
  whatsapp: <WhatsAppIcon />,
  linkedin: <LinkedInIcon />,
}

export function HeroSection() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 -left-40 w-96 h-96 bg-primary/15 rounded-full blur-3xl animate-pulse-glow" />
        <div
          className="absolute top-40 right-0 w-80 h-80 bg-accent/15 rounded-full blur-3xl animate-pulse-glow"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="absolute bottom-0 left-1/3 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse-glow"
          style={{ animationDelay: "4s" }}
        />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="grid items-center gap-16 lg:grid-cols-2 lg:gap-12">
          <div className="max-w-xl">
            <div className="mb-8 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary/10 to-accent/10 px-4 py-2 border border-primary/20">
              <Sparkles className="h-4 w-4 text-primary animate-pulse" />
              <span className="text-sm font-semibold text-foreground">Potenciado por IA + Embeddings</span>
            </div>

            <h1 className="text-balance text-5xl font-bold tracking-tight md:text-6xl lg:text-7xl">
              <span className="text-foreground">Una bandeja,</span>
              <br />
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-gradient bg-[length:200%_auto]">
                todas tus conversaciones.
              </span>
            </h1>

            <p className="mt-8 text-pretty text-lg leading-relaxed text-foreground/70 md:text-xl">
              LYO unifica todos tus mensajes, correos y contactos. Aprende inteligentemente tus objetivos, entiende lo
              que más importa, y redacta respuestas que suenan como tú.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <div className="flex items-center gap-2 rounded-full bg-white border border-border px-4 py-2 text-sm shadow-sm">
                <Brain className="h-4 w-4 text-primary" />
                <span className="font-medium text-foreground">Memoria IA</span>
              </div>
              <div className="flex items-center gap-2 rounded-full bg-white border border-border px-4 py-2 text-sm shadow-sm">
                <Zap className="h-4 w-4 text-accent" />
                <span className="font-medium text-foreground">Respuestas Auto</span>
              </div>
              <div className="flex items-center gap-2 rounded-full bg-white border border-border px-4 py-2 text-sm shadow-sm">
                <Mail className="h-4 w-4 text-primary" />
                <span className="font-medium text-foreground">Multi-canal</span>
              </div>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-4">
              <Link href="/dashboard">
                <Button
                  size="lg"
                  className="rounded-full px-8 gap-2 bg-gradient-to-r from-primary to-accent text-white hover:opacity-90 shadow-xl shadow-primary/30 transition-all hover:shadow-2xl hover:shadow-primary/40 hover:-translate-y-0.5"
                >
                  Comenzar Gratis
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="#demo">
                <Button
                  variant="outline"
                  size="lg"
                  className="rounded-full px-8 border-border bg-white hover:bg-secondary text-foreground"
                >
                  Ver Demo
                </Button>
              </Link>
            </div>
          </div>

          <div className="relative lg:ml-8">
            <div className="absolute -top-6 -right-4 z-20 w-72 rounded-2xl bg-white p-4 shadow-2xl shadow-black/10 border border-border animate-float">
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-50 to-red-100">
                  <GmailIcon />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">Natasha Corwin</p>
                  <p className="mt-1 text-xs leading-relaxed text-foreground/70">
                    Ha solicitado un <span className="font-semibold text-foreground">contrato de venta</span>. Encontré
                    un email relacionado.
                  </p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs font-medium text-foreground/60">24m</span>
                </div>
              </div>
            </div>

            <div className="absolute top-24 -right-8 z-20 w-64 rounded-2xl bg-white p-4 shadow-2xl shadow-black/10 border border-border animate-float-delayed">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-green-50 to-green-100">
                  <WhatsAppIcon />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">Luke Rankin</p>
                  <p className="mt-0.5 text-xs text-foreground/70">Revisar actualización proyecto ITWA</p>
                </div>
              </div>
            </div>

            <div className="absolute top-48 -right-2 z-20 w-60 rounded-2xl bg-white p-4 shadow-2xl shadow-black/10 border border-border animate-float-slow">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-purple-50 to-pink-100">
                  <SlackIcon />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">Ben Monroe</p>
                  <p className="mt-0.5 text-xs text-foreground/70">Proveer gastos del Q3</p>
                </div>
              </div>
            </div>

            <div className="relative rounded-3xl bg-white shadow-2xl shadow-black/10 overflow-hidden border border-border">
              <div className="flex items-center gap-2 border-b border-border px-5 py-4 bg-secondary/30">
                <div className="h-3 w-3 rounded-full bg-[#FF5F56] shadow-sm" />
                <div className="h-3 w-3 rounded-full bg-[#FFBD2E] shadow-sm" />
                <div className="h-3 w-3 rounded-full bg-[#27CA40] shadow-sm" />
              </div>

              <div className="flex">
                <div className="w-14 border-r border-border bg-secondary/20 py-5">
                  <div className="flex flex-col items-center gap-3">
                    <button className="flex h-10 w-10 items-center justify-center rounded-xl bg-white shadow-md border border-border ring-2 ring-primary/20">
                      <Mail className="h-5 w-5 text-primary" />
                    </button>
                    {[GmailIcon, InstagramIcon, LinkedInIcon, SlackIcon, WhatsAppIcon].map((Icon, i) => (
                      <button
                        key={i}
                        className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-white/80 transition-all hover:shadow-md"
                      >
                        <Icon />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-3 border-b border-border px-5 py-4">
                    <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-primary/10 to-accent/10">
                      <Sparkles className="h-4 w-4 text-primary" />
                    </div>
                    <span className="text-sm text-foreground/60">Pregunta a LYO cualquier cosa...</span>
                    <div className="ml-auto flex items-center gap-1 rounded-lg bg-secondary px-2 py-1">
                      <span className="text-xs text-foreground/60 font-mono">⌘K</span>
                    </div>
                  </div>

                  <div className="border-b border-border px-5 py-3 bg-secondary/20">
                    <span className="text-sm font-semibold text-foreground">Bandeja de entrada</span>
                    <span className="ml-2 text-xs text-primary font-semibold">4 nuevos</span>
                  </div>

                  <div className="max-h-72 overflow-hidden">
                    {conversations.map((conv, i) => (
                      <div
                        key={i}
                        className={`flex items-start gap-3 px-5 py-4 border-b border-border/50 hover:bg-secondary/30 transition-all cursor-pointer ${i === 0 ? "bg-primary/5" : ""}`}
                      >
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-secondary text-sm font-semibold text-foreground/70 shadow-sm">
                          {conv.avatar}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-foreground">{conv.name}</span>
                            <span className="text-xs text-foreground/50">{conv.time}</span>
                          </div>
                          <p className="mt-1 text-xs text-foreground/60 truncate">{conv.preview}</p>
                        </div>
                        <div className="shrink-0 p-1">{channelIcons[conv.channel]}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="absolute bottom-4 left-4 w-60 rounded-2xl bg-white p-5 shadow-xl border border-border">
                <div className="flex items-center gap-2 mb-2">
                  <div className="h-6 w-6 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                    <Sparkles className="h-3 w-3 text-white" />
                  </div>
                  <span className="text-xs font-bold text-primary">LYO AI</span>
                </div>
                <p className="text-sm font-semibold text-foreground">Buenos días, Sarah.</p>
                <p className="mt-1 text-xs text-foreground/70">Tienes 4 nuevas y 9 conversaciones activas</p>
                <div className="mt-4 flex items-center gap-2 rounded-xl bg-gradient-to-r from-primary/10 to-accent/10 px-4 py-2.5 border border-primary/20 cursor-pointer hover:from-primary/20 hover:to-accent/20 transition-colors">
                  <span className="text-xs font-semibold text-foreground">Pregunta a LYO</span>
                  <ChevronRight className="ml-auto h-3 w-3 text-primary" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Integration icons */}
        <div className="mt-20 flex flex-wrap items-center justify-center gap-4 md:gap-6">
          {[
            { icon: <GmailIcon />, bg: "from-red-50 to-orange-50" },
            { icon: <SlackIcon />, bg: "from-purple-50 to-pink-50" },
            { icon: <InstagramIcon />, bg: "from-pink-50 to-purple-50" },
            { icon: <WhatsAppIcon />, bg: "from-green-50 to-emerald-50" },
            { icon: <LinkedInIcon />, bg: "from-blue-50 to-cyan-50" },
            { icon: <CalendarIcon />, bg: "from-blue-50 to-indigo-50" },
          ].map((item, i) => (
            <div
              key={i}
              className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${item.bg} shadow-lg shadow-black/5 border border-white transition-all hover:-translate-y-1 hover:shadow-xl cursor-pointer`}
            >
              {item.icon}
            </div>
          ))}
        </div>

        <div className="mt-16 flex flex-col items-center gap-4">
          <p className="text-foreground/70 text-lg">
            Únete a <span className="font-bold text-primary text-2xl">12,773</span> personas en la lista de espera.
          </p>
          <Link href="/waitlist">
            <Button
              size="lg"
              className="rounded-full px-10 gap-2 bg-foreground text-background hover:bg-foreground/90 shadow-xl"
            >
              Unirse ahora
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
