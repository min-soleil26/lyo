const stats = [
  { value: "10x", label: "faster responses", company: "Founders" },
  { value: "85%", label: "time saved", company: "Freelancers" },
  { value: "500+", label: "meetings automated", company: "Sales Teams" },
  { value: "99.9%", label: "uptime", company: "Enterprise" },
]

export function StatsSection() {
  return (
    <section className="border-y border-border bg-card/30">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {stats.map((stat, index) => (
            <div key={index} className="text-center md:text-left">
              <div className="text-3xl font-semibold tracking-tight md:text-4xl">{stat.value}</div>
              <div className="mt-1 text-sm text-muted-foreground">{stat.label}</div>
              <div className="mt-3 text-xs font-medium uppercase tracking-wider text-muted-foreground/60">
                {stat.company}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
