"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, ChevronRight, Sparkles } from "lucide-react"

export function LandingNavbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="mx-4 mt-4 rounded-2xl bg-white/90 backdrop-blur-xl border border-border/50 shadow-lg shadow-black/5">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2.5 group">
              <div className="relative h-9 w-9">
                <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-primary via-accent to-primary animate-gradient opacity-90" />
                <div className="absolute inset-[2px] rounded-[10px] bg-white flex items-center justify-center">
                  <Sparkles className="h-4 w-4 text-primary" />
                </div>
              </div>
              <span className="text-xl font-bold tracking-tight text-foreground">LYO</span>
            </Link>

            <div className="hidden items-center gap-1 md:flex">
              <span className="mx-4 h-5 w-px bg-border" />
              <Link
                href="#about"
                className="px-4 py-2 text-sm font-medium text-foreground/80 transition-all hover:text-foreground hover:bg-secondary rounded-lg"
              >
                Acerca de
              </Link>
              <Link
                href="#features"
                className="px-4 py-2 text-sm font-medium text-foreground/80 transition-all hover:text-foreground hover:bg-secondary rounded-lg"
              >
                Características
              </Link>
              <Link
                href="#faqs"
                className="px-4 py-2 text-sm font-medium text-foreground/80 transition-all hover:text-foreground hover:bg-secondary rounded-lg"
              >
                Preguntas
              </Link>
            </div>
          </div>

          <div className="hidden items-center gap-3 md:flex">
            <Link href="/login">
              <Button
                variant="ghost"
                size="sm"
                className="rounded-full px-5 text-foreground/80 hover:text-foreground hover:bg-secondary"
              >
                Iniciar Sesión
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button
                size="sm"
                className="rounded-full px-5 gap-1.5 bg-gradient-to-r from-primary to-accent text-white hover:opacity-90 transition-opacity shadow-lg shadow-primary/30"
              >
                Comenzar
                <ChevronRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          <button
            className="md:hidden p-2 hover:bg-secondary rounded-lg transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-5 w-5 text-foreground" /> : <Menu className="h-5 w-5 text-foreground" />}
          </button>
        </nav>

        {mobileMenuOpen && (
          <div className="border-t border-border px-6 py-4 md:hidden">
            <div className="flex flex-col gap-2">
              <Link
                href="#about"
                className="text-sm font-medium text-foreground/80 py-2 px-3 hover:bg-secondary rounded-lg transition-colors"
              >
                Acerca de
              </Link>
              <Link
                href="#features"
                className="text-sm font-medium text-foreground/80 py-2 px-3 hover:bg-secondary rounded-lg transition-colors"
              >
                Características
              </Link>
              <Link
                href="#faqs"
                className="text-sm font-medium text-foreground/80 py-2 px-3 hover:bg-secondary rounded-lg transition-colors"
              >
                Preguntas
              </Link>
              <div className="flex gap-2 pt-4">
                <Link href="/login" className="flex-1">
                  <Button variant="outline" className="w-full rounded-full bg-transparent">
                    Iniciar Sesión
                  </Button>
                </Link>
                <Link href="/dashboard" className="flex-1">
                  <Button className="w-full rounded-full bg-gradient-to-r from-primary to-accent text-white">
                    Comenzar
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
