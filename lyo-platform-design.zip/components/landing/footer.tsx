import Link from "next/link"
import { Github, Twitter, Linkedin, Sparkles } from "lucide-react"

const footerLinks = {
  producto: [
    { label: "Características", href: "#features" },
    { label: "Integraciones", href: "#integrations" },
    { label: "Precios", href: "/pricing" },
    { label: "Novedades", href: "/changelog" },
  ],
  empresa: [
    { label: "Acerca de", href: "/about" },
    { label: "Blog", href: "/blog" },
    { label: "Carreras", href: "/careers" },
    { label: "Contacto", href: "/contact" },
  ],
  recursos: [
    { label: "Documentación", href: "/docs" },
    { label: "API Reference", href: "/api" },
    { label: "Centro de Ayuda", href: "/help" },
    { label: "Estado", href: "/status" },
  ],
  legal: [
    { label: "Privacidad", href: "/privacy" },
    { label: "Términos", href: "/terms" },
    { label: "Seguridad", href: "/security" },
  ],
}

export function Footer() {
  return (
    <footer className="relative border-t border-border bg-gradient-to-b from-background to-secondary/30 overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-72 h-72 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6 py-16 md:py-20">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-6">
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2.5 group">
              <div className="relative h-9 w-9">
                <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-primary via-accent to-primary animate-gradient opacity-90" />
                <div className="absolute inset-[2px] rounded-[10px] bg-white flex items-center justify-center">
                  <Sparkles className="h-4 w-4 text-primary" />
                </div>
              </div>
              <span className="text-xl font-bold tracking-tight text-foreground">LYO</span>
            </Link>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-foreground/70">
              Tu hub de comunicación potenciado por IA. Unifica todos los canales y deja que la inteligencia se encargue
              del resto.
            </p>
            <div className="mt-6 flex gap-3">
              {[
                { icon: Twitter, href: "https://twitter.com" },
                { icon: Github, href: "https://github.com" },
                { icon: Linkedin, href: "https://linkedin.com" },
              ].map((social, i) => (
                <Link
                  key={i}
                  href={social.href}
                  className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-foreground/60 hover:bg-primary hover:text-white transition-all hover:-translate-y-0.5"
                >
                  <social.icon className="h-4 w-4" />
                </Link>
              ))}
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-sm font-bold text-foreground capitalize">{category}</h3>
              <ul className="mt-5 space-y-3">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link href={link.href} className="text-sm text-foreground/60 hover:text-primary transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-foreground/60">
              © {new Date().getFullYear()} LYO. Todos los derechos reservados.
            </p>
            <div className="flex items-center gap-2 text-sm text-foreground/60">
              <span className="flex h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              <span>Todos los sistemas operativos</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
