import { ArrowRight } from "lucide-react"

const steps = [
  {
    number: "01",
    title: "Connect your channels",
    description: "Link WhatsApp, Gmail, LinkedIn, Instagram, and Calendar in just a few clicks.",
  },
  {
    number: "02",
    title: "Train your AI agent",
    description: "Configure your agent's personality, tone, and response rules. Upload context documents.",
  },
  {
    number: "03",
    title: "Let LYO work for you",
    description: "Your agent responds to messages, schedules meetings, and maintains relationships automatically.",
  },
]

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-20 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-medium uppercase tracking-wider text-accent">How it works</p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            Get started in three simple steps
          </h2>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {index < steps.length - 1 && (
                <ArrowRight className="absolute -right-4 top-8 hidden h-6 w-6 text-border md:block" />
              )}
              <div className="rounded-xl border border-border bg-card/50 p-6">
                <div className="mb-4 text-4xl font-bold text-accent/30">{step.number}</div>
                <h3 className="text-lg font-medium">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
