import { MessageCircle, Mail, Linkedin, Instagram, CalendarDays, Database } from "lucide-react"

const integrations = [
  {
    name: "WhatsApp",
    description: "Business API integration",
    icon: MessageCircle,
    color: "text-green-400",
    bgColor: "bg-green-400/10",
  },
  {
    name: "Gmail",
    description: "OAuth secure access",
    icon: Mail,
    color: "text-red-400",
    bgColor: "bg-red-400/10",
  },
  {
    name: "LinkedIn",
    description: "Messages & connections",
    icon: Linkedin,
    color: "text-blue-400",
    bgColor: "bg-blue-400/10",
  },
  {
    name: "Instagram",
    description: "Direct messages",
    icon: Instagram,
    color: "text-pink-400",
    bgColor: "bg-pink-400/10",
  },
  {
    name: "Calendar",
    description: "Google Calendar sync",
    icon: CalendarDays,
    color: "text-yellow-400",
    bgColor: "bg-yellow-400/10",
  },
  {
    name: "Supabase",
    description: "Vector embeddings",
    icon: Database,
    color: "text-emerald-400",
    bgColor: "bg-emerald-400/10",
  },
]

export function IntegrationsSection() {
  return (
    <section id="integrations" className="border-y border-border bg-card/30 py-20 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <p className="text-sm font-medium uppercase tracking-wider text-accent">Integrations</p>
            <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight md:text-4xl">
              Connect all your channels in minutes
            </h2>
            <p className="mt-4 text-muted-foreground">
              LYO integrates with the tools you already use. Set up once and let your AI agent handle the rest.
            </p>

            <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3">
              {integrations.map((integration, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 rounded-lg border border-border bg-card/50 p-3 transition-colors hover:bg-card"
                >
                  <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${integration.bgColor}`}>
                    <integration.icon className={`h-5 w-5 ${integration.color}`} />
                  </div>
                  <div>
                    <div className="text-sm font-medium">{integration.name}</div>
                    <div className="text-xs text-muted-foreground">{integration.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square rounded-2xl border border-border bg-card/50 p-8">
              <IntegrationDiagram />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function IntegrationDiagram() {
  return (
    <div className="relative flex h-full items-center justify-center">
      {/* Center LYO logo */}
      <div className="absolute z-10 flex h-20 w-20 items-center justify-center rounded-2xl border border-accent/50 bg-card shadow-lg shadow-accent/20">
        <span className="text-2xl font-bold">LYO</span>
      </div>

      {/* Orbiting icons */}
      <div className="absolute h-full w-full animate-spin" style={{ animationDuration: "30s" }}>
        <div className="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-400/10 text-green-400">
            <MessageCircle className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-400/10 text-red-400">
            <Mail className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-400/10 text-blue-400">
            <Linkedin className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute left-0 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-pink-400/10 text-pink-400">
            <Instagram className="h-6 w-6" />
          </div>
        </div>
      </div>

      {/* Connection lines */}
      <div className="absolute h-48 w-48 rounded-full border border-dashed border-border/50" />
      <div className="absolute h-64 w-64 rounded-full border border-dashed border-border/30" />
    </div>
  )
}
