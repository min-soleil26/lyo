"use client"

import { MessageSquare, Brain, Calendar, Users, Zap, Shield, ArrowRight } from "lucide-react"

const features = [
  {
    icon: MessageSquare,
    title: "Bandeja Unificada",
    description:
      "Todos tus mensajes de WhatsApp, Gmail, LinkedIn e Instagram en un solo lugar. Nunca más pierdas una conversación.",
    gradient: "from-blue-500 to-cyan-500",
    bgGradient: "from-blue-50 to-cyan-50",
  },
  {
    icon: Brain,
    title: "Memoria IA",
    description:
      "Tu agente recuerda cada interacción usando embeddings. Respuestas con contexto que se sienten personales.",
    gradient: "from-purple-500 to-pink-500",
    bgGradient: "from-purple-50 to-pink-50",
  },
  {
    icon: Calendar,
    title: "Agenda Inteligente",
    description:
      "Creación automática de reuniones desde lenguaje natural. Sincronización perfecta con Google Calendar.",
    gradient: "from-amber-500 to-orange-500",
    bgGradient: "from-amber-50 to-orange-50",
  },
  {
    icon: Users,
    title: "Inteligencia de Contactos",
    description:
      "Perfiles de contacto enriquecidos con historial de interacciones, preferencias e insights generados por IA.",
    gradient: "from-emerald-500 to-teal-500",
    bgGradient: "from-emerald-50 to-teal-50",
  },
  {
    icon: Zap,
    title: "Respuestas Instantáneas",
    description:
      "Respuestas potenciadas por IA que coinciden con tu tono. Revisa, edita o deja que LYO lo maneje automáticamente.",
    gradient: "from-rose-500 to-red-500",
    bgGradient: "from-rose-50 to-red-50",
  },
  {
    icon: Shield,
    title: "Seguridad Empresarial",
    description:
      "Encriptación de extremo a extremo, cumplimiento SOC2 y controles de acceso granulares para tu equipo.",
    gradient: "from-indigo-500 to-violet-500",
    bgGradient: "from-indigo-50 to-violet-50",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -top-20 -left-20 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary/10 to-accent/10 px-4 py-2 border border-primary/20">
            <Zap className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">Características Poderosas</span>
          </div>

          <h2 className="text-balance text-4xl font-bold tracking-tight md:text-5xl">
            <span className="text-foreground">Todo lo que necesitas para</span>
            <br />
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              gestionar comunicaciones
            </span>
          </h2>
          <p className="mt-6 text-lg text-foreground/70">
            Características poderosas diseñadas para fundadores, freelancers y equipos que necesitan estar al tanto de
            cada conversación.
          </p>
        </div>

        <div className="mt-20 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative rounded-2xl bg-white p-8 border border-border shadow-lg shadow-black/5 hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 hover:-translate-y-1 overflow-hidden"
            >
              <div
                className={`absolute inset-0 bg-gradient-to-br ${feature.bgGradient} opacity-0 group-hover:opacity-50 transition-opacity duration-300`}
              />

              <div className="relative">
                <div
                  className={`mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${feature.gradient} shadow-lg`}
                >
                  <feature.icon className="h-7 w-7 text-white" />
                </div>

                <h3 className="text-xl font-bold text-foreground">{feature.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-foreground/70">{feature.description}</p>

                <div className="mt-6 flex items-center gap-2 text-sm font-semibold text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Saber más</span>
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-24 rounded-3xl bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5 border border-border p-10 md:p-14">
          <div className="grid gap-8 md:grid-cols-4">
            {[
              { value: "50K+", label: "Usuarios Activos" },
              { value: "2M+", label: "Mensajes Procesados" },
              { value: "99.9%", label: "Tiempo Activo" },
              { value: "4.9", label: "Calificación" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent md:text-5xl">
                  {stat.value}
                </div>
                <div className="mt-2 text-sm font-medium text-foreground/70">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
